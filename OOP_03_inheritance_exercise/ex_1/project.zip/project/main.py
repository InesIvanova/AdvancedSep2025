from project.child import Child

child = Child('John', 20)

print(child.age)